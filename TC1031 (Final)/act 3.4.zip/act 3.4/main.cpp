#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <map>
#include <set>
#include <algorithm>

using namespace std;

struct LogEntry {
    string month;
    int day;
    string time;
    string ipAddress;
    string reason;
};

struct LogEntryNode {
    LogEntry entry;
    LogEntryNode* next;

    LogEntryNode(const LogEntry& logEntry) : entry(logEntry), next(nullptr) {}
};

class LinkedList {
public:
    LinkedList() : head(nullptr) {}

    void addLogEntry(const LogEntry& entry) {
        LogEntryNode* newNode = new LogEntryNode(entry);
        newNode->next = head;
        head = newNode;

        // Incrementar el contador en el árbol BST
        ipAccessCount[entry.ipAddress]++;
    }

    void printLogEntries() {
        LogEntryNode* current = head;
        while (current != nullptr) {
            cout << "Month: " << current->entry.month << endl;
            cout << "Day: " << current->entry.day << endl;
            cout << "Time: " << current->entry.time << endl;
            cout << "IP Address: " << current->entry.ipAddress << endl;
            cout << "Reason: " << current->entry.reason << endl;
            cout << "=========================" << endl;
            current = current->next;
        }
    }

    void sortLogEntries() {
        head = mergeSort(head);
    }

    int binarySearch(const string& targetIP) {
        int index = 0;
        LogEntryNode* current = head;

        while (current != nullptr) {
            if (current->entry.ipAddress == targetIP) {
                return index; // En caso que se encuentre la dirección IP
            }

            current = current->next;
            index++;
        }

        return -1; // En caso de que no se encuentre
    }

    void printLogEntriesInRange(const string& startIP, const string& endIP) {
        LogEntryNode* current = head;
        bool inRange = false;

        ofstream outputFile("output.txt");
        if (!outputFile.is_open()) {
            cerr << "Failed to create the output file." << endl;
            return;
        }

        while (current != nullptr) {
            if (current->entry.ipAddress == startIP) {
                inRange = true;
            }
            // Se imprimen los atributos de la clase
            if (inRange) {
                outputFile << "Month: " << current->entry.month << endl;
                outputFile << "Day: " << current->entry.day << endl;
                outputFile << "Time: " << current->entry.time << endl;
                outputFile << "IP Address: " << current->entry.ipAddress << endl;
                outputFile << "Reason: " << current->entry.reason << endl;
                outputFile << "=========================" << endl;
            }

            if (current->entry.ipAddress == endIP) {
                break;
            }

            current = current->next;
        }

        outputFile.close();
        cout << "Output file 'output.txt' created with log entries in the specified range." << endl;
    }

    // Función para obtener el árbol BST con el conteo de accesos por IP
    map<string, int> getIpAccessCount() const {
        return ipAccessCount;
    }

    ~LinkedList() {
        while (head != nullptr) {
            LogEntryNode* temp = head;
            head = head->next;
            delete temp;
        }
    }

private:
    LogEntryNode* head;

    // Se prepara el programa para Merge Sort
    LogEntryNode* merge(LogEntryNode* left, LogEntryNode* right) {
        LogEntryNode dummyNode(LogEntry{"", 0, "", "", ""});
        LogEntryNode* current = &dummyNode;

        while (left != nullptr && right != nullptr) {
            if (left->entry.ipAddress <= right->entry.ipAddress) {
                current->next = left;
                left = left->next;
            } else {
                current->next = right;
                right = right->next;
            }
            current = current->next;
        }

        current->next = (left != nullptr) ? left : right;
        return dummyNode.next;
    }

    // Se aplica el Merge Sort a la entrada del nodo
    LogEntryNode* mergeSort(LogEntryNode* head) {
        if (head == nullptr || head->next == nullptr) {
            return head;
        }

        LogEntryNode* slow = head;
        LogEntryNode* fast = head->next;
        while (fast != nullptr) {
            fast = fast->next;
            if (fast != nullptr) {
                fast = fast->next;
                slow = slow->next;
            }
        }

        LogEntryNode* left = head;
        LogEntryNode* right = slow->next;
        slow->next = nullptr;

        left = mergeSort(left);
        right = mergeSort(right);

        return merge(left, right);
    }

    // Estructura para almacenar el conteo de accesos por IP
    map<string, int> ipAccessCount;
};

// Función para comparar dos pares de dirección IP y número de accesos
bool compareIpAccessPair(const pair<string, int>& p1, const pair<string, int>& p2) {
    return p1.second > p2.second;
}

int main() {
    ifstream file("bitacora.txt");
    if (!file.is_open()) {
        cerr << "Failed to open the database file." << endl;
        return 1;
    }

    vector<LogEntry> logEntries;
    string line;
    while (getline(file, line)) {
        istringstream iss(line);
        LogEntry entry;
        iss >> entry.month >> entry.day >> entry.time >> entry.ipAddress;
        getline(iss, entry.reason);
        logEntries.push_back(entry);
    }

    LinkedList logList;
    for (const LogEntry& entry : logEntries) {
        logList.addLogEntry(entry);
    }

    logList.sortLogEntries();

    // Obtener el árbol BST con el conteo de accesos por IP
    map<string, int> ipAccessCount = logList.getIpAccessCount();

    // Convertir el mapa a un vector de pares para facilitar la clasificación
    vector<pair<string, int>> ipAccessVector(ipAccessCount.begin(), ipAccessCount.end());

    // Ordenar el vector en función del número de accesos
    sort(ipAccessVector.begin(), ipAccessVector.end(), compareIpAccessPair);

    // Imprimir las cinco IPs con más accesos
    cout << "Top 5 IPs with the most accesses:" << endl;
    for (int i = 0; i < min(5, static_cast<int>(ipAccessVector.size())); ++i) {
        cout << "IP Address: " << ipAccessVector[i].first << ", Access Count: " << ipAccessVector[i].second << endl;
    }

    return 0;
}
