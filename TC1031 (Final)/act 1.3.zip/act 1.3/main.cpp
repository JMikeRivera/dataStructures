#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <map>
#include <cmath>
#include <climits>
using namespace std;


/* we use the map function to facilitate the mergeSort and binary search */
map<string, int> monthToNumber = {
    {"Jan", 1}, {"Feb", 2}, {"Mar", 3}, {"Apr", 4},
    {"May", 5}, {"Jun", 6}, {"Jul", 7}, {"Aug", 8},
    {"Sep", 9}, {"Oct", 10}, {"Nov", 11}, {"Dec", 12}
};


/* we do an inverse map to be able to turn back those numbers into the 3 letter month format */
map<int, string> numberToMonth;


/* we transform the time in format hh:mm:ss into a single number, this will help us sort it 
and search for it, so if the hour is 13:00:00 it will become 130000, if we have a second hour
14:00:00 it will become 140000, if we compare these 2 numbers we know 140000 is bigger than 130000
and thus the hour is more late */
int timeToNumber(const string& timeStr) {
    int hh, mm, ss;
    char colon;
    stringstream ss_time(timeStr);
    ss_time >> hh >> colon >> mm >> colon >> ss;
    return hh * 10000 + mm * 100 + ss;
}


/* the inverse of TimeToNumber function, it will help us transform a number in the format 130000 to the 
format 13:00:00 */
string numberToTime(int timeNum) {
    int hh = timeNum / 10000;
    int mm = (timeNum / 100) % 100;
    int ss = timeNum % 100;
    stringstream ss_time;
    ss_time << setw(2) << setfill('0') << hh << ":" << setw(2) << setfill('0') << mm << ":" << setw(2) << setfill('0') << ss;
    return ss_time.str();
}


/* the function concatenateComponents receives the int monthNumber (which we get from the map function), int day and
int timeNumber (which we get from the TimeToNumber function), we concatenate them to be able to sort them with the same 
logic we applied in the TimeToNumber function */
long long concatenateComponents(int monthNumber, int day, int timeNumber) {
    /* static cast to convert the datatype from int to long long */
    return static_cast<long long>(monthNumber) * 100000000 + static_cast<long long>(day) * 1000000 + static_cast<long long>(timeNumber);
}


/* function to concatenate user input */
long long concatenateUserInput(int month, int day, int time) {
    return static_cast<long long>(month) * 100000000 + static_cast<long long>(day) * 1000000 + static_cast<long long>(time);
}


/* we use the struct data type to be able to read the dataBase more easily */
struct LogEntry {
    long long concatenatedValue; 
    string ipAddress;
    string reason;

    LogEntry(long long concatenatedValue, const string& ipAddress, const string& reason)
        : concatenatedValue(concatenatedValue), ipAddress(ipAddress), reason(reason) {}

    int getMonth() const {
        return static_cast<int>(concatenatedValue / 100000000);
    }

    int getDay() const {
        return static_cast<int>((concatenatedValue / 1000000) % 100);
    }

    int getTimeNumber() const {
        return static_cast<int>(concatenatedValue % 1000000);
    }
};


/* parseLogEntries read the dataBase and stores it in a vector to further manipulation */
vector<LogEntry> parseLogEntries(const string& filePath) {
    ifstream logFile(filePath);
    if (!logFile.is_open()) {
        cout << "Failed to open log file." << endl;
        exit(1);
    }

    string line;
    vector<LogEntry> logEntries;

    while (getline(logFile, line)) {
        istringstream iss(line);
        string monthName, time, ipAddress, reason;
        int day;

        if (iss >> monthName >> day >> time >> ipAddress) {
            getline(iss, reason);

            int monthNumber = monthToNumber[monthName];
            int timeNumber = timeToNumber(time);

            long long concatenatedValue = concatenateComponents(monthNumber, day, timeNumber);

            logEntries.emplace_back(concatenatedValue, ipAddress, reason);
        }
    }

    logFile.close();
    return logEntries;
}


/* merge function to merge two sorted vectors based on concatenatedValue, which we got before */ 
vector<LogEntry> merge(vector<LogEntry>& left, vector<LogEntry>& right) {
    vector<LogEntry> result;
    size_t leftIndex = 0;
    size_t rightIndex = 0;

    while (leftIndex < left.size() && rightIndex < right.size()) {
        if (left[leftIndex].concatenatedValue < right[rightIndex].concatenatedValue) {
            result.push_back(left[leftIndex]);
            leftIndex++;
        } else {
            result.push_back(right[rightIndex]);
            rightIndex++;
        }
    }

    /* we add remaining elements, if any */
    while (leftIndex < left.size()) {
        result.push_back(left[leftIndex]);
        leftIndex++;
    }

    while (rightIndex < right.size()) {
        result.push_back(right[rightIndex]);
        rightIndex++;
    }

    return result;
}


/* recursive mergeSort */
vector<LogEntry> mergeSort(vector<LogEntry>& logEntries) {
    if (logEntries.size() <= 1) {
        return logEntries;
    }

    size_t middle = logEntries.size() / 2;
    vector<LogEntry> left(logEntries.begin(), logEntries.begin() + middle);
    vector<LogEntry> right(logEntries.begin() + middle, logEntries.end());

    left = mergeSort(left);
    right = mergeSort(right);

    return merge(left, right);
}


/* binary search function, slightly modified fromt standard to find the closest index, isntead of the exact
index of a certain date */
int binarySearch(vector<LogEntry>& logEntries, long long target) {
    int left = 0;
    int right = logEntries.size() - 1;
    int closestIndex = -1;
    long long closestValue = LLONG_MAX; /* variable to store the closest value found*/ 

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (logEntries[mid].concatenatedValue == target) {
            return mid; /* found the exact target */
        } else if (logEntries[mid].concatenatedValue < target) {
            left = mid + 1; /* target is in the right half */
        } else {
            right = mid - 1; /* target is in the left half */
        }

        /* we calculate the absolute difference from the target */ 
        long long diff = abs(logEntries[mid].concatenatedValue - target);

        if (diff < closestValue) {
            closestValue = diff;
            closestIndex = mid;
        }
    }

    return closestIndex;
}


int main() {
    for (const auto& pair : monthToNumber) {
        numberToMonth[pair.second] = pair.first;
    }

    string filePath = "./bitacora.txt";
    vector<LogEntry> logEntries = parseLogEntries(filePath);

    /* call to merge sort */
    logEntries = mergeSort(logEntries);

    cout << "Enter the start date (MM DD HH:MM:SS): ";
    int startMonth, startDay, startTime;
    cin >> startMonth >> startDay;
    string startTimeStr;
    cin.ignore(); /* we consume the newline character (just in case) */
    getline(cin, startTimeStr);
    startTime = timeToNumber(startTimeStr);

    cout << "Enter the end date (MM DD HH:MM:SS): ";
    int endMonth, endDay, endTime;
    cin >> endMonth >> endDay;
    string endTimeStr;
    cin.ignore(); /* we consume the newline character (just in case) */
    getline(cin, endTimeStr);
    endTime = timeToNumber(endTimeStr);

    /* we find the indexes with a call to bianry search function */
    int startIndex = binarySearch(logEntries, concatenateComponents(startMonth, startDay, startTime));
    int endIndex = binarySearch(logEntries, concatenateComponents(endMonth, endDay, endTime));

    if (startIndex == -1 || endIndex == -1) {
        cout << "Start or end date not found in the log entries." << endl;
        return 1;
    }

    /* we open a new file, this time ofstream to write in it */
    ofstream outputFile("output.txt");
    if (!outputFile.is_open()) {
        cout << "Failed to create output file." << endl;
        return 1;
    }

    /* We write the entries that match between the 2 dates */
    for (int i = startIndex; i <= endIndex; i++) {
        outputFile << "Month: " << numberToMonth[logEntries[i].getMonth()] << endl;
        outputFile << "Day: " << logEntries[i].getDay() << endl;
        outputFile << "Time: " << numberToTime(logEntries[i].getTimeNumber()) << endl;
        outputFile << "IP Address: " << logEntries[i].ipAddress << endl;
        outputFile << "Reason: " << logEntries[i].reason << endl;
        outputFile << "=========================" << endl;
    }

    outputFile.close();
    cout << "Output file 'output.txt' created with entries between start and end dates." << endl;

    return 0;
}






