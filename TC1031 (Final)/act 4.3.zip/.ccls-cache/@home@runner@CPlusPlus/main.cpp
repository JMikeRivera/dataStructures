#include <iostream>

int main() {
  std::cout << "Hello World!\n";
}