#include <iostream>
#include <vector>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>

struct LogNode {
    std::string timestamp;
    std::vector<std::string> actions;
};

std::unordered_map<std::string, LogNode> logGraph;

std::string roundTimestampToHour(const std::string& timestamp) {
    std::tm timeInfo = {};
    std::istringstream iss(timestamp);
    iss >> std::get_time(&timeInfo, "%b %d %H:%M:%S");
    timeInfo.tm_min = 0;
    timeInfo.tm_sec = 0;

    std::ostringstream oss;
    oss << std::put_time(&timeInfo, "%m-%d %H:00:00");
    return oss.str();
}

void readLogFile(const std::string& filename) {
    std::ifstream file(filename);
    std::string line;

    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string month, day, time, ipAddress, action;
        iss >> month >> day >> time >> ipAddress;
        size_t colonPos = ipAddress.find(':');
        if (colonPos != std::string::npos) {
            ipAddress = ipAddress.substr(0, colonPos);
        }

        std::string timestamp = month + " " + day + " " + time;
        std::string roundedTimestamp = roundTimestampToHour(timestamp);

        if (logGraph.find(roundedTimestamp) == logGraph.end()) {
            logGraph[roundedTimestamp] = LogNode();
            logGraph[roundedTimestamp].timestamp = roundedTimestamp;
        }

        std::getline(iss >> std::ws, action);
        logGraph[roundedTimestamp].actions.push_back(action);
    }
}

std::unordered_map<std::string, int> calculateFanouts() {
    std::unordered_map<std::string, int> fanoutMap;

    for (const auto& entry : logGraph) {
        const std::string& roundedTimestamp = entry.first;
        const LogNode& node = entry.second;
        fanoutMap[roundedTimestamp] = node.actions.size();
    }

    return fanoutMap;
}

bool sortByTimestamp(const std::pair<std::string, int>& lhs, const std::pair<std::string, int>& rhs) {
    std::string monthLhs = lhs.first.substr(0, 5);
    std::string monthRhs = rhs.first.substr(0, 5);

    if (monthLhs != monthRhs) {
        return monthLhs < monthRhs;
    }

    std::string dayLhs = lhs.first.substr(6, 2);
    std::string dayRhs = rhs.first.substr(6, 2);

    return dayLhs < dayRhs;
}

void saveFanoutsToFile(const std::unordered_map<std::string, int>& fanoutMap, const std::string& outputFile) {
    std::ofstream out(outputFile);
    if (!out.is_open()) {
        std::cerr << "Error: Unable to open the output file " << outputFile << std::endl;
        return;
    }

    out << "\nFan-out for each node:" << std::endl;
    std::vector<std::pair<std::string, int>> sortedFanouts(fanoutMap.begin(), fanoutMap.end());
    std::sort(sortedFanouts.begin(), sortedFanouts.end(), sortByTimestamp);

    for (const auto& entry : sortedFanouts) {
        const std::string& roundedTimestamp = entry.first;
        int fanout = entry.second;
        out << "Node: " << roundedTimestamp << ", Fan-out: " << fanout << std::endl;
    }

    std::cout << "Fan-out information is in: " << outputFile << std::endl;
    out.close();
}

bool sortByFanoutsDescending(const std::pair<std::string, int>& lhs, const std::pair<std::string, int>& rhs) {
    return lhs.second > rhs.second;
}

void printTopNFanouts(const std::unordered_map<std::string, int>& fanoutMap, int N) {
    std::cout << "\nTop " << N << " nodes with the highest fan-outs:" << std::endl;
    std::vector<std::pair<std::string, int>> sortedFanouts(fanoutMap.begin(), fanoutMap.end());
    std::sort(sortedFanouts.begin(), sortedFanouts.end(), sortByFanoutsDescending);

    for (int i = 0; i < N && i < sortedFanouts.size(); ++i) {
        const auto& entry = sortedFanouts[i];
        std::cout << "Node: " << entry.first << ", Fan-out: " << entry.second << std::endl;
    }
}

std::string findNodeWithMaxFanout(const std::unordered_map<std::string, int>& fanoutMap) {
    std::string maxTimestamp;
    int maxFanout = -1;

    for (const auto& entry : fanoutMap) {
        const std::string& roundedTimestamp = entry.first;
        int fanout = entry.second;

        if (fanout > maxFanout) {
            maxFanout = fanout;
            maxTimestamp = roundedTimestamp;
        }
    }

    return maxTimestamp;
}

void determineBootMasterLocation(const std::string& bootMasterTimestamp) {
    if (logGraph.find(bootMasterTimestamp) != logGraph.end()) {
        const LogNode& node = logGraph[bootMasterTimestamp];
        std::cout << "\nBoot master is at: " << bootMasterTimestamp << std::endl;
        std::cout << "\nActions performed:" << std::endl;

        for (const std::string& action : node.actions) {
            std::cout << "  " << action << std::endl;
        }
    } else {
        std::cout << "Timestamp not found." << std::endl;
    }
}

int main() {
    readLogFile("bitacora.txt");
    std::unordered_map<std::string, int> fanoutMap = calculateFanouts();

    int choice;
    do {
        std::cout << "\n----------------- MENU -----------------\n";
        std::cout << "1. Print fan-out for each node\n";
        std::cout << "2. Print the top 10 fan-outs\n";
        std::cout << "3. Print the boot master's location\n";
        std::cout << "4. Quit";
        std::cout << "\n----------------------------------------\n";
        std::cout << "\nEnter an option: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                std::cout << "\nThe results are too long to print in the terminal.\n";
                saveFanoutsToFile(fanoutMap, "FanOutForEachNode.txt");
                break;
            }
            case 2: {
                printTopNFanouts(fanoutMap, 10);
                break;
            }
            case 3: {
                std::string bootMasterTimestamp = findNodeWithMaxFanout(fanoutMap);
                determineBootMasterLocation(bootMasterTimestamp);
                break;
            }
            case 4: {
                std::cout << "\nEnd of the program.\n";
                break;
            }
            default: {
                std::cout << "\nInvalid input. Please check and try again.\n";
            }
        }
    } while (choice != 4);

    return 0;
}
